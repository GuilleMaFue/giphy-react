import React, { useState } from 'react';
import { AddCategory } from './components/AddCategory';
import {GifGrid} from './components/GifGrid';

export const GitExpertApp = () => {
    const [categorias, setCategories] = useState(['One Punch']);
    
    return( 
        <>
        <h2>GitExpertApp</h2>
        <AddCategory 
             setCategories={setCategories} />
        <hr/>
        <ul>
            {categorias.map(listado => (
                <GifGrid 
                    key={listado}
                    categoria={listado} 
                />
            ))}
        </ul>
        </>
     );
}