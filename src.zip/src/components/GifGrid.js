import React, {useState, useEffect} from 'react'
import {GifGridItem} from './GifGridItem';
import {getGifs} from '../helpers/getGifs';

export const GifGrid = ({ categoria }) => {
   
    const [images, setImages] = useState([]);

    useEffect(() => {
        getGifs(categoria)
            .then(setImages);
    }, [])

    return (
        <>
           <h3> { categoria } </h3> 
           <div className="card-grid">
           <ol>
                {images.map( img => (
                    <GifGridItem 
                        key={img.id}
                        {...img} 
                    />
                ))}
           </ol>
        </div>
        </>
    )
}
