import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import {GitExpertApp} from './GitExpertApp';

const divRoot = document.getElementById('root');

ReactDOM.render(<GitExpertApp />,divRoot);
